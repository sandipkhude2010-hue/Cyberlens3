import os
import unittest
import tempfile
from datetime import datetime, timedelta
import pandas as pd
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, get_db, seed_database
from detector import AnomalyDetector
from simulator import AttackSimulator

class TestCyberLensDetector(unittest.TestCase):
    def setUp(self):
        # Use an isolated temporary database for tests
        self.temp_db_fd, self.temp_db_path = tempfile.mkstemp(suffix='.db')
        init_db(self.temp_db_path)
        seed_database(self.temp_db_path)
        self.detector = AnomalyDetector(self.temp_db_path)
        self.simulator = AttackSimulator(self.temp_db_path)

    def tearDown(self):
        os.close(self.temp_db_fd)
        if os.path.exists(self.temp_db_path):
            os.remove(self.temp_db_path)

    def test_database_initialization(self):
        conn = get_db(self.temp_db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        self.assertIn('users', tables)
        self.assertIn('login_activity', tables)
        self.assertIn('security_alerts', tables)

        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        self.assertGreaterEqual(user_count, 4)
        conn.close()

    def test_user_authentication_hashing(self):
        conn = get_db(self.temp_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT password_hash FROM users WHERE username = 'admin'")
        pwd_hash = cursor.fetchone()[0]
        self.assertTrue(check_password_hash(pwd_hash, 'Admin@123'))
        self.assertFalse(check_password_hash(pwd_hash, 'WrongPassword!'))
        conn.close()

    def test_rule_1_brute_force(self):
        now = datetime.now()
        username = 'test_victim'
        ip = '198.51.100.99'

        # Log 3 consecutive failed logins
        for i in range(3):
            t = (now - timedelta(seconds=(3 - i) * 10)).strftime('%Y-%m-%d %H:%M:%S')
            res = self.simulator.log_and_detect(
                username=username,
                status='FAILED',
                ip=ip,
                timestamp=t,
                failure_reason='Bad password'
            )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'BRUTE_FORCE' for a in res['alerts']))
        self.assertTrue(any(a['severity'] == 'HIGH' for a in res['alerts']))

    def test_rule_2_ip_hopping(self):
        now = datetime.now()
        username = 'test_roamer'
        ips = ['10.0.0.1', '10.0.0.2', '10.0.0.3']

        for i, ip in enumerate(ips):
            t = (now - timedelta(minutes=(3 - i))).strftime('%Y-%m-%d %H:%M:%S')
            res = self.simulator.log_and_detect(
                username=username,
                status='FAILED',
                ip=ip,
                timestamp=t,
                failure_reason='Distributed attempt'
            )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'IP_HOPPING' for a in res['alerts']))

    def test_rule_3_geolocation_anomaly(self):
        username = 'sarah_dev'  # Has baseline history in New York, United States
        now = datetime.now()

        # Login from Tokyo, Japan shortly after
        t = now.strftime('%Y-%m-%d %H:%M:%S')
        res = self.simulator.log_and_detect(
            username=username,
            status='SUCCESS',
            ip='10.0.0.88',
            timestamp=t,
            city='Tokyo',
            country='Japan'
        )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'GEOLOCATION_ANOMALY' for a in res['alerts']))

    def test_rule_4_off_hours(self):
        username = 'john_user'
        now = datetime.now().replace(hour=3, minute=15, second=0)
        t = now.strftime('%Y-%m-%d %H:%M:%S')

        res = self.simulator.log_and_detect(
            username=username,
            status='SUCCESS',
            ip='192.168.1.100',
            timestamp=t,
            city='New York',
            country='United States'
        )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'OFF_HOURS' for a in res['alerts']))

    def test_rule_5_rapid_burst(self):
        now = datetime.now()
        username = 'bot_target'
        ip = '203.0.113.50'

        for i in range(3):
            t = (now - timedelta(seconds=(3 - i))).strftime('%Y-%m-%d %H:%M:%S')
            res = self.simulator.log_and_detect(
                username=username,
                status='FAILED',
                ip=ip,
                timestamp=t,
                failure_reason='Bot flood'
            )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'RAPID_BURST' for a in res['alerts']))

    def test_rule_6_failed_then_success(self):
        now = datetime.now()
        username = 'cracked_user'
        ip = '185.220.101.5'

        # 2 failures
        for i in range(2):
            t = (now - timedelta(minutes=5 - i)).strftime('%Y-%m-%d %H:%M:%S')
            self.simulator.log_and_detect(
                username=username,
                status='FAILED',
                ip=ip,
                timestamp=t,
                failure_reason='Wrong pin'
            )

        # Successful login
        success_t = now.strftime('%Y-%m-%d %H:%M:%S')
        res = self.simulator.log_and_detect(
            username=username,
            status='SUCCESS',
            ip=ip,
            timestamp=success_t
        )

        self.assertTrue(res['is_suspicious'])
        self.assertTrue(any(a['alert_type'] == 'FAILED_THEN_SUCCESS' for a in res['alerts']))

    def test_alert_resolution_flow(self):
        conn = get_db(self.temp_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM security_alerts WHERE status = 'PENDING' LIMIT 1")
        alert_id = cursor.fetchone()[0]

        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute("""
            UPDATE security_alerts
            SET status = 'RESOLVED', resolved_at = ?, resolved_by = 'admin'
            WHERE id = ?
        """, (now_str, alert_id))
        conn.commit()

        cursor.execute("SELECT status, resolved_by FROM security_alerts WHERE id = ?", (alert_id,))
        row = cursor.fetchone()
        self.assertEqual(row['status'], 'RESOLVED')
        self.assertEqual(row['resolved_by'], 'admin')
        conn.close()

    def test_pandas_analytics_computation(self):
        analytics = self.detector.get_security_analytics()
        self.assertIn('metrics', analytics)
        self.assertIn('trends', analytics)
        self.assertIn('severity_dist', analytics)
        self.assertIn('attack_types', analytics)
        self.assertIn('hourly_dist', analytics)
        self.assertEqual(len(analytics['hourly_dist']), 24)
        self.assertGreater(analytics['metrics']['total_attempts'], 0)

if __name__ == '__main__':
    unittest.main()
