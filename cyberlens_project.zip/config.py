import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'cyberlens-super-secure-key-2026-x99f8')
    DATABASE = os.path.join(BASE_DIR, 'cyberlens.db')
    DEBUG = True

    # Anomaly Detection Engine Thresholds
    # Rule 1: Brute Force Detection
    BRUTE_FORCE_THRESHOLD = 3          # Failed attempts to trigger alert
    BRUTE_FORCE_WINDOW_MINUTES = 10    # Time window for failed attempts

    # Rule 2: Distributed IP / Credential Stuffing Detection
    DISTRIBUTED_IP_THRESHOLD = 2       # Distinct IPs targeting same user
    DISTRIBUTED_IP_WINDOW_MINUTES = 15 # Time window for multi-IP check

    # Rule 3: Geolocation Anomaly
    LOCATION_HISTORY_LIMIT = 5         # Look back count to determine baseline user locations

    # Rule 4: Off-Hours Login
    OFF_HOURS_START = 1                # 1:00 AM
    OFF_HOURS_END = 5                  # 5:00 AM (inclusive threshold)

    # Rule 5: High-Frequency / Rapid Bot Attempts
    RAPID_BURST_THRESHOLD = 3          # Attempts within burst window
    RAPID_BURST_WINDOW_SECONDS = 8     # Seconds window for rapid bursts

    # Rule 6: Failed-Then-Success Pattern (Breach / Credential Cracking Success)
    FAILED_THEN_SUCCESS_PRIOR_FAILURES = 2  # Prior failed attempts before success
    FAILED_THEN_SUCCESS_WINDOW_MINUTES = 15 # Time window to link failures to success

    # Known IP to Geo mapping for offline demonstration
    DEMO_GEO_MAP = {
        '192.168.1.100': ('New York', 'United States'),
        '192.168.1.101': ('San Francisco', 'United States'),
        '10.0.0.15': ('London', 'United Kingdom'),
        '10.0.0.88': ('Tokyo', 'Japan'),
        '172.16.0.42': ('Berlin', 'Germany'),
        '172.16.5.99': ('Sydney', 'Australia'),
        '198.51.100.22': ('Moscow', 'Russia'),
        '203.0.113.77': ('Singapore', 'Singapore'),
        '185.220.101.5': ('Amsterdam', 'Netherlands'),
        '127.0.0.1': ('Local Workstation', 'Internal Network')
    }
