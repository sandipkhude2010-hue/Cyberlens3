"""
CyberLens 24/7 Background Sentinel Watchdog
Keeps both the Waitress WSGI server and the Cloudflare Tunnel running continuously.
Automatically restarts any service if it disconnects or encounters network drops.
"""

import subprocess
import time
import sys
import os
import urllib.request

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
FLASK_APP = os.path.join(BASE_DIR, "app.py")
CLOUDFLARED = os.path.join(BASE_DIR, "cloudflared.exe")

def is_local_server_healthy():
    """Checks if the local Waitress server is responding on port 5000."""
    try:
        req = urllib.request.Request("http://127.0.0.1:5000/login", headers={"User-Agent": "CyberLens-Watchdog/1.0"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False

def run_watchdog():
    print("=" * 60)
    print(" [CYBERLENS 24/7 AUTONOMOUS WATCHDOG DAEMON]")
    print(" Ensuring 24/7 uptime for local backend and public tunnel...")
    print("=" * 60)

    server_process = None
    tunnel_process = None

    while True:
        # 1. Check or start Local Server (Waitress WSGI)
        if not is_local_server_healthy() or server_process is None or server_process.poll() is not None:
            if server_process and server_process.poll() is not None:
                print("[!] Local server stopped unexpectedly. Restarting...", flush=True)
            else:
                print("[+] Starting CyberLens Waitress production server...", flush=True)

            server_process = subprocess.Popen([sys.executable, FLASK_APP], cwd=BASE_DIR)
            time.sleep(3)

        # 2. Check or start Cloudflare Tunnel
        if tunnel_process is None or tunnel_process.poll() is not None:
            if tunnel_process and tunnel_process.poll() is not None:
                print("[!] Cloudflare tunnel connection dropped. Auto-reconnecting...", flush=True)
            else:
                print("[+] Initializing Cloudflare 24/7 public tunnel...", flush=True)

            if os.path.exists(CLOUDFLARED):
                tunnel_process = subprocess.Popen(
                    [CLOUDFLARED, "tunnel", "--url", "http://127.0.0.1:5000"],
                    cwd=BASE_DIR
                )
            else:
                print("[!] cloudflared.exe not found. Running local server only.")

        time.sleep(10)

if __name__ == "__main__":
    run_watchdog()
