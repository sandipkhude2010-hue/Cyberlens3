import time
from datetime import datetime, timedelta
from config import Config
from database import get_db, reset_database
from detector import AnomalyDetector

class AttackSimulator:
    """
    Simulation Engine for testing and evaluating CyberLens detection rules.
    Provides automated scenarios matching real-world attack vectors.
    """

    def __init__(self, db_path=None):
        self.db_path = db_path or Config.DATABASE
        self.detector = AnomalyDetector(self.db_path)

    def log_and_detect(self, username, status, ip, user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64)", 
                       timestamp=None, city=None, country=None, failure_reason=None, browser="Chrome", os_name="Windows", device="Desktop"):
        """Inserts a login activity record and processes it through the anomaly detector."""
        conn = get_db(self.db_path)
        cursor = conn.cursor()

        if timestamp is None:
            now_dt = datetime.now()
            timestamp_str = now_dt.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(timestamp, datetime):
            timestamp_str = timestamp.strftime('%Y-%m-%d %H:%M:%S')
        else:
            timestamp_str = str(timestamp)

        # Lookup location if not provided
        if not city or not country:
            geo = Config.DEMO_GEO_MAP.get(ip, ('Unknown City', 'Unknown Region'))
            city, country = geo[0], geo[1]

        # Check if user exists in database to associate user_id
        cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
        user_row = cursor.fetchone()
        user_id = user_row[0] if user_row else None

        cursor.execute("""
            INSERT INTO login_activity (
                user_id, username, timestamp, ip_address, status,
                user_agent, browser, os, device, city, country, is_suspicious, failure_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
        """, (user_id, username, timestamp_str, ip, status, user_agent, browser, os_name, device, city, country, failure_reason))

        activity_id = cursor.lastrowid
        conn.commit()
        conn.close()

        # Run Anomaly Detection Engine
        alerts = self.detector.analyze_login_attempt(
            activity_id=activity_id,
            username=username,
            ip_address=ip,
            status=status,
            timestamp_str=timestamp_str,
            city=city,
            country=country
        )

        return {
            'activity_id': activity_id,
            'username': username,
            'timestamp': timestamp_str,
            'ip_address': ip,
            'status': status,
            'city': city,
            'country': country,
            'is_suspicious': len(alerts) > 0,
            'alerts': alerts
        }

    def run_scenario(self, scenario_type, target_user="sarah_dev"):
        """Executes a pre-configured attack demonstration scenario."""
        results = []
        now = datetime.now()

        if scenario_type == 'normal':
            # Scenario 1: Normal Authorized Login
            res = self.log_and_detect(
                username=target_user,
                status='SUCCESS',
                ip='192.168.1.100',
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0',
                timestamp=now,
                city='New York',
                country='United States',
                browser='Chrome',
                os_name='Windows',
                device='Desktop'
            )
            results.append(res)

        elif scenario_type == 'brute_force':
            # Scenario 2: Multiple Failed Logins in rapid succession (Brute Force)
            attacker_ip = '198.51.100.22'
            for i in range(4):
                attempt_time = now - timedelta(seconds=(4 - i) * 15)
                res = self.log_and_detect(
                    username=target_user,
                    status='FAILED',
                    ip=attacker_ip,
                    user_agent='Hydra-BruteForce-Engine/9.2',
                    timestamp=attempt_time,
                    city='Moscow',
                    country='Russia',
                    failure_reason='Incorrect password attempt',
                    browser='Hydra/Bot',
                    os_name='Linux',
                    device='Server'
                )
                results.append(res)

        elif scenario_type == 'ip_hopping':
            # Scenario 3: Login attempts from multiple distinct IPs (Distributed / Credential Stuffing)
            locations = [
                ('10.0.0.15', 'London', 'United Kingdom'),
                ('10.0.0.88', 'Tokyo', 'Japan'),
                ('172.16.0.42', 'Berlin', 'Germany')
            ]
            for i, (ip, city, country) in enumerate(locations):
                attempt_time = now - timedelta(minutes=(3 - i) * 2)
                res = self.log_and_detect(
                    username=target_user,
                    status='FAILED',
                    ip=ip,
                    user_agent='Mozilla/5.0 (X11; Linux x86_64)',
                    timestamp=attempt_time,
                    city=city,
                    country=country,
                    failure_reason='Authentication failed from proxy node',
                    browser='Firefox',
                    os_name='Linux',
                    device='Proxy Server'
                )
                results.append(res)

        elif scenario_type == 'unusual_hours':
            # Scenario 4: Login at Unusual Hours (Simulated at 03:30 AM)
            night_time = now.replace(hour=3, minute=30, second=15)
            res = self.log_and_detect(
                username=target_user,
                status='SUCCESS',
                ip='192.168.1.100',
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0',
                timestamp=night_time,
                city='New York',
                country='United States',
                browser='Chrome',
                os_name='Windows',
                device='Desktop'
            )
            results.append(res)

        elif scenario_type == 'failed_then_success':
            # Scenario 5: Multiple Failures followed by Successful Login (Compromised Account)
            ip = '185.220.101.5'
            for i in range(3):
                attempt_time = now - timedelta(minutes=4 - i)
                self.log_and_detect(
                    username=target_user,
                    status='FAILED',
                    ip=ip,
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
                    timestamp=attempt_time,
                    city='Amsterdam',
                    country='Netherlands',
                    failure_reason='Invalid credentials',
                    browser='Safari',
                    os_name='macOS',
                    device='Laptop'
                )
            # The breaching success:
            success_time = now
            res = self.log_and_detect(
                username=target_user,
                status='SUCCESS',
                ip=ip,
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
                timestamp=success_time,
                city='Amsterdam',
                country='Netherlands',
                browser='Safari',
                os_name='macOS',
                device='Laptop'
            )
            results.append(res)

        elif scenario_type == 'rapid_burst':
            # Scenario 6: High frequency bot bursts (< 8 seconds)
            bot_ip = '203.0.113.77'
            for i in range(4):
                attempt_time = now - timedelta(seconds=(4 - i))
                res = self.log_and_detect(
                    username=target_user,
                    status='FAILED',
                    ip=bot_ip,
                    user_agent='Python-requests/2.31.0 CyberSprayer',
                    timestamp=attempt_time,
                    city='Singapore',
                    country='Singapore',
                    failure_reason='Rate limit burst attempt',
                    browser='Bot/Script',
                    os_name='Linux',
                    device='Botnet Node'
                )
                results.append(res)

        elif scenario_type == 'reset':
            reset_database(self.db_path)
            return {'message': 'Database reinitialized to clean demonstration state.'}

        return {
            'scenario': scenario_type,
            'target_user': target_user,
            'logs_generated': len(results),
            'results': results
        }
