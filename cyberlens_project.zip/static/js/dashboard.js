/**
 * CyberLens Dashboard Chart.js Visualizations & Live Telemetry
 */

let trendsChart, severityChart, attackTypesChart, hourlyChart;

document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    fetchDashboardTelemetry();

    // Auto-refresh stats every 15 seconds
    setInterval(fetchDashboardTelemetry, 15000);
});

function initCharts() {
    // 1. Login Trends Chart (Line / Area)
    const ctxTrends = document.getElementById('loginTrendsChart')?.getContext('2d');
    if (ctxTrends) {
        trendsChart = new Chart(ctxTrends, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Successful Logins',
                        data: [],
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.12)',
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#10b981',
                        pointBorderColor: '#070d18',
                        pointBorderWidth: 2,
                        pointRadius: 4
                    },
                    {
                        label: 'Failed / Blocked Logins',
                        data: [],
                        borderColor: '#f43f5e',
                        backgroundColor: 'rgba(244, 63, 94, 0.12)',
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#f43f5e',
                        pointBorderColor: '#070d18',
                        pointBorderWidth: 2,
                        pointRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#94a3b8', font: { family: 'Inter', size: 12 } }
                    },
                    tooltip: {
                        backgroundColor: '#131f38',
                        titleColor: '#fff',
                        bodyColor: '#94a3b8',
                        borderColor: '#1e3358',
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#64748b', font: { family: 'JetBrains Mono', size: 11 } }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#64748b', stepSize: 1, font: { family: 'JetBrains Mono', size: 11 } }
                    }
                }
            }
        });
    }

    // 2. Threat Severity Doughnut Chart
    const ctxSev = document.getElementById('threatSeverityChart')?.getContext('2d');
    if (ctxSev) {
        severityChart = new Chart(ctxSev, {
            type: 'doughnut',
            data: {
                labels: ['High Severity', 'Medium Severity', 'Low Severity'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: ['#f43f5e', '#f59e0b', '#38bdf8'],
                    borderColor: '#0e172a',
                    borderWidth: 3,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#94a3b8', padding: 16, font: { family: 'Inter', size: 12 } }
                    }
                }
            }
        });
    }

    // 3. Attack Types Bar Chart
    const ctxTypes = document.getElementById('attackTypesChart')?.getContext('2d');
    if (ctxTypes) {
        attackTypesChart = new Chart(ctxTypes, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Alert Occurrences',
                    data: [],
                    backgroundColor: 'rgba(6, 182, 212, 0.6)',
                    borderColor: '#06b6d4',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#64748b', stepSize: 1, font: { family: 'JetBrains Mono', size: 11 } }
                    },
                    y: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8', font: { family: 'Inter', size: 11 } }
                    }
                }
            }
        });
    }

    // 4. Hourly Activity 24h Distribution Bar Chart
    const ctxHourly = document.getElementById('hourlyActivityChart')?.getContext('2d');
    if (ctxHourly) {
        const hours = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`);
        hourlyChart = new Chart(ctxHourly, {
            type: 'bar',
            data: {
                labels: hours,
                datasets: [{
                    label: 'Authentication Attempts',
                    data: new Array(24).fill(0),
                    backgroundColor: hours.map((_, i) => (i >= 1 && i <= 5) ? 'rgba(244, 63, 94, 0.55)' : 'rgba(16, 185, 129, 0.45)'),
                    borderColor: hours.map((_, i) => (i >= 1 && i <= 5) ? '#f43f5e' : '#10b981'),
                    borderWidth: 1,
                    borderRadius: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            afterLabel: function(ctx) {
                                const h = ctx.dataIndex;
                                return (h >= 1 && h <= 5) ? 'Off-Hours Window (1 AM - 5 AM)' : 'Standard Hours';
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b', font: { family: 'JetBrains Mono', size: 10 } }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#64748b', stepSize: 1, font: { family: 'JetBrains Mono', size: 11 } }
                    }
                }
            }
        });
    }
}

async function fetchDashboardTelemetry() {
    try {
        const res = await fetch('/api/dashboard/stats');
        if (!res.ok) return;
        const data = await res.json();

        // Update KPI Counters
        if (data.metrics) {
            updateKpiCounter('kpi-total-attempts', data.metrics.total_attempts);
            updateKpiCounter('kpi-success-logins', data.metrics.success_count);
            updateKpiCounter('kpi-failed-logins', data.metrics.failed_count);
            updateKpiCounter('kpi-active-alerts', data.metrics.pending_alerts);
            updateKpiCounter('kpi-failure-rate', `${data.metrics.failure_rate}%`);
        }

        // Update Trends Chart
        if (trendsChart && data.trends) {
            trendsChart.data.labels = data.trends.labels.length ? data.trends.labels : ['No recent logs'];
            trendsChart.data.datasets[0].data = data.trends.success;
            trendsChart.data.datasets[1].data = data.trends.failed;
            trendsChart.update();
        }

        // Update Severity Doughnut Chart
        if (severityChart && data.severity_dist) {
            severityChart.data.datasets[0].data = [
                data.severity_dist.HIGH || 0,
                data.severity_dist.MEDIUM || 0,
                data.severity_dist.LOW || 0
            ];
            severityChart.update();
        }

        // Update Attack Types Bar Chart
        if (attackTypesChart && data.attack_types) {
            const types = Object.keys(data.attack_types);
            const counts = Object.values(data.attack_types);
            attackTypesChart.data.labels = types;
            attackTypesChart.data.datasets[0].data = counts;
            attackTypesChart.update();
        }

        // Update Hourly Distribution Chart
        if (hourlyChart && data.hourly_dist) {
            hourlyChart.data.datasets[0].data = data.hourly_dist;
            hourlyChart.update();
        }

    } catch (err) {
        console.error('Failed to fetch dashboard telemetry:', err);
    }
}

function updateKpiCounter(elementId, value) {
    const el = document.getElementById(elementId);
    if (el) {
        el.textContent = value;
    }
}
