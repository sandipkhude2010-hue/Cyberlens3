/**
 * CyberLens Global Utilities
 */

document.addEventListener('DOMContentLoaded', () => {
    // Auto-dismiss alert banners after 6 seconds
    const alerts = document.querySelectorAll('.alert-box');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 6000);
    });
});

/**
 * Creates and displays an ephemeral toast notification
 */
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position: fixed; bottom: 24px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 10px;';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const colorMap = {
        success: '#10b981',
        danger: '#f43f5e',
        warning: '#f59e0b',
        info: '#06b6d4'
    };
    const accent = colorMap[type] || '#06b6d4';

    toast.style.cssText = `
        background-color: #131f38;
        color: #ffffff;
        border-left: 4px solid ${accent};
        border-radius: 8px;
        padding: 14px 18px;
        font-size: 0.88rem;
        box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 280px;
        animation: slideInRight 0.3s ease;
    `;

    toast.innerHTML = `
        <span style="color: ${accent}; font-weight: bold;">●</span>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.4s ease';
        setTimeout(() => toast.remove(), 400);
    }, 4500);
}
