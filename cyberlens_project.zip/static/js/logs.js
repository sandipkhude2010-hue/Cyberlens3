/**
 * CyberLens Audit Log Explorer Logic
 */

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('log-search-input');
    const table = document.getElementById('audit-logs-table');

    if (searchInput && table) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            const rows = table.querySelectorAll('tbody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(query)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    const exportBtn = document.getElementById('btn-export-csv');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            window.location.href = '/api/logs/export';
            showToast('Generating and downloading audit CSV...', 'info');
        });
    }
});
