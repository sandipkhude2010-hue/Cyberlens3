/**
 * CyberLens Security Alerts Management Logic
 */

document.addEventListener('DOMContentLoaded', () => {
    initAlertActions();
});

function initAlertActions() {
    // Resolve Button Click
    document.querySelectorAll('.btn-resolve-alert').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const alertId = btn.dataset.alertId;
            if (!alertId) return;

            btn.disabled = true;
            btn.innerHTML = `<span style="font-size:0.75rem;">Resolving...</span>`;

            try {
                const res = await fetch(`/api/alerts/${alertId}/resolve`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const data = await res.json();

                if (data.success) {
                    showToast(`Alert #${alertId} successfully resolved`, 'success');
                    
                    // Update Row in UI
                    const row = document.getElementById(`alert-row-${alertId}`);
                    if (row) {
                        const statusCell = row.querySelector('.alert-status-cell');
                        if (statusCell) {
                            statusCell.innerHTML = `<span class="badge badge-resolved">RESOLVED</span>`;
                        }
                        const actionCell = row.querySelector('.alert-action-cell');
                        if (actionCell) {
                            actionCell.innerHTML = `<span style="font-size: 0.78rem; color: #10b981;">Resolved</span>`;
                        }
                    }

                    // Decrement Pending Counter Pill
                    const pendingCounter = document.getElementById('pending-alerts-count');
                    if (pendingCounter) {
                        let cur = parseInt(pendingCounter.textContent) || 0;
                        pendingCounter.textContent = Math.max(0, cur - 1);
                    }
                } else {
                    showToast('Failed to resolve alert', 'danger');
                    btn.disabled = false;
                    btn.textContent = 'Resolve';
                }
            } catch (err) {
                console.error(err);
                showToast('Error communicating with security backend', 'danger');
                btn.disabled = false;
                btn.textContent = 'Resolve';
            }
        });
    });

    // Dismiss Button Click
    document.querySelectorAll('.btn-dismiss-alert').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const alertId = btn.dataset.alertId;
            if (!alertId) return;

            btn.disabled = true;

            try {
                const res = await fetch(`/api/alerts/${alertId}/dismiss`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const data = await res.json();

                if (data.success) {
                    showToast(`Alert #${alertId} dismissed`, 'info');
                    const row = document.getElementById(`alert-row-${alertId}`);
                    if (row) {
                        row.style.opacity = '0.4';
                        const actionCell = row.querySelector('.alert-action-cell');
                        if (actionCell) actionCell.innerHTML = `<span style="font-size: 0.78rem; color: #64748b;">Dismissed</span>`;
                    }
                }
            } catch (err) {
                console.error(err);
                showToast('Error dismissing alert', 'danger');
                btn.disabled = false;
            }
        });
    });
}
