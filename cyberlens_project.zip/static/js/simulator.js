/**
 * CyberLens Attack Simulation Lab Controller
 */

document.addEventListener('DOMContentLoaded', () => {
    initSimulator();
});

function initSimulator() {
    const terminal = document.getElementById('terminal-content');
    const userSelect = document.getElementById('target-user-select');

    function appendTerminal(line, cssClass = '') {
        if (!terminal) return;
        const p = document.createElement('div');
        p.className = `log-line ${cssClass}`;
        const time = new Date().toTimeString().split(' ')[0];
        p.innerHTML = `<span style="color:#64748b;">[${time}]</span> ${line}`;
        terminal.appendChild(p);
        terminal.scrollTop = terminal.scrollHeight;
    }

    // Attach listeners to all scenario trigger buttons
    document.querySelectorAll('.btn-run-scenario').forEach(btn => {
        btn.addEventListener('click', async () => {
            const scenario = btn.dataset.scenario;
            const targetUser = userSelect ? userSelect.value : 'sarah_dev';

            // Disable buttons during execution
            document.querySelectorAll('.btn-run-scenario').forEach(b => b.disabled = true);
            const originalText = btn.innerHTML;
            btn.innerHTML = `<span>Simulating...</span>`;

            appendTerminal(`------------------------------------------------------------`, '');
            appendTerminal(`⚡ INITIATING ATTACK VECTOR: <strong style="color:#06b6d4;">${scenario.toUpperCase()}</strong>`, '');
            appendTerminal(`Target Account: <strong style="color:#fff;">${targetUser}</strong>`, '');

            try {
                const res = await fetch('/api/simulator/run', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ scenario, target_user: targetUser })
                });

                const json = await res.json();

                if (json.success && json.data) {
                    const data = json.data;
                    appendTerminal(`Transmission completed. ${data.logs_generated} event(s) logged to SQLite.`, 'log-success');

                    let totalAlerts = 0;
                    if (data.results && data.results.length) {
                        data.results.forEach((r, idx) => {
                            const statusColor = r.status === 'SUCCESS' ? '#10b981' : '#f43f5e';
                            appendTerminal(
                                `Attempt #${idx+1}: IP=<span style="color:#94a3b8;">${r.ip_address}</span> (${r.city}, ${r.country}) -> Status=<strong style="color:${statusColor}">${r.status}</strong>`
                            );

                            if (r.alerts && r.alerts.length > 0) {
                                r.alerts.forEach(alert => {
                                    totalAlerts++;
                                    const sevClass = alert.severity === 'HIGH' ? 'log-alert-high' : 
                                                     (alert.severity === 'MEDIUM' ? 'log-alert-medium' : 'log-alert-low');
                                    appendTerminal(`⚠️ [ALERT TRIGGERED] [${alert.severity}] ${alert.alert_type}: ${alert.reason}`, sevClass);
                                });
                            }
                        });
                    }

                    if (totalAlerts > 0) {
                        showToast(`Attack detected! ${totalAlerts} security alert(s) generated.`, 'danger');
                        appendTerminal(`🛑 THREAT DETECTED: CyberLens generated ${totalAlerts} real-time alert(s).`, 'log-alert-high');
                    } else {
                        showToast(`Scenario executed: No anomalies triggered (Normal Activity).`, 'success');
                        appendTerminal(`✔ System assessment: Authentication pattern is clean and authorized.`, 'log-success');
                    }
                } else {
                    appendTerminal(`❌ Error executing scenario: ${json.message || 'Unknown error'}`, 'log-alert-high');
                    showToast('Simulation failed', 'danger');
                }
            } catch (err) {
                console.error(err);
                appendTerminal(`❌ Network communication error during simulation.`, 'log-alert-high');
                showToast('Simulation error', 'danger');
            } finally {
                document.querySelectorAll('.btn-run-scenario').forEach(b => b.disabled = false);
                btn.innerHTML = originalText;
            }
        });
    });

    // Reset Demo Data Button
    const resetBtn = document.getElementById('btn-reset-demo');
    if (resetBtn) {
        resetBtn.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to reset the database to baseline demo state? This will clear newly added test logs.')) return;

            resetBtn.disabled = true;
            resetBtn.textContent = 'Resetting...';

            try {
                const res = await fetch('/api/simulator/reset', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const data = await res.json();
                if (data.success) {
                    showToast('Database reset to clean baseline state.', 'info');
                    appendTerminal(`🔄 Database reinitialized to default demonstration schema and records.`, 'log-alert-low');
                }
            } catch (err) {
                console.error(err);
                showToast('Failed to reset database', 'danger');
            } finally {
                resetBtn.disabled = false;
                resetBtn.textContent = 'Reset Baseline Data';
            }
        });
    }

    // Clear Terminal Button
    const clearBtn = document.getElementById('btn-clear-terminal');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (terminal) {
                terminal.innerHTML = '<div class="log-line" style="color:#64748b;">Terminal cleared. Ready for attack execution.</div>';
            }
        });
    }
}
