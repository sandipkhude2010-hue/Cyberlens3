import sqlite3
import os
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
from config import Config

def get_db(db_path=None):
    """Establishes and returns a database connection with Row factory."""
    path = db_path or Config.DATABASE
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db(db_path=None):
    """Creates the SQLite database schema if not already existing."""
    conn = get_db(db_path)
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created_at TEXT NOT NULL,
        last_login TEXT
    );
    """)

    # 2. Login Activity Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS login_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        ip_address TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('SUCCESS', 'FAILED')),
        user_agent TEXT,
        browser TEXT,
        os TEXT,
        device TEXT,
        city TEXT,
        country TEXT,
        is_suspicious INTEGER DEFAULT 0,
        failure_reason TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );
    """)

    # 3. Security Alerts Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS security_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        activity_id INTEGER NOT NULL,
        username TEXT NOT NULL,
        alert_type TEXT NOT NULL,
        severity TEXT NOT NULL CHECK(severity IN ('LOW', 'MEDIUM', 'HIGH')),
        reason TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'RESOLVED')),
        created_at TEXT NOT NULL,
        resolved_at TEXT,
        resolved_by TEXT,
        FOREIGN KEY (activity_id) REFERENCES login_activity(id) ON DELETE CASCADE
    );
    """)

    # Performance Indices
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_activity_user_time ON login_activity(username, timestamp);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_activity_ip ON login_activity(ip_address);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_status_sev ON security_alerts(status, severity);")

    conn.commit()
    conn.close()

def seed_database(db_path=None):
    """Populates baseline demonstration data if the users table is empty."""
    conn = get_db(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    now = datetime.now()

    # Seed Users
    users_data = [
        ('admin', 'admin@cyberlens.local', generate_password_hash('Admin@123'), 'admin', (now - timedelta(days=30)).isoformat()),
        ('sarah_dev', 'sarah@cyberlens.local', generate_password_hash('Sarah@2026'), 'user', (now - timedelta(days=20)).isoformat()),
        ('alex_analyst', 'alex@cyberlens.local', generate_password_hash('Alex@2026'), 'user', (now - timedelta(days=15)).isoformat()),
        ('john_user', 'john@cyberlens.local', generate_password_hash('John@2026'), 'user', (now - timedelta(days=10)).isoformat()),
    ]

    cursor.executemany("""
        INSERT INTO users (username, email, password_hash, role, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, users_data)

    # Seed Historical Login Records & Baseline Activity
    sample_logins = [
        # Normal Sarah Logins (New York, USA)
        (2, 'sarah_dev', (now - timedelta(hours=36)).strftime('%Y-%m-%d %H:%M:%S'), '192.168.1.100', 'SUCCESS', 'Chrome / Windows', 'Chrome', 'Windows', 'Desktop', 'New York', 'United States', 0, None),
        (2, 'sarah_dev', (now - timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S'), '192.168.1.100', 'SUCCESS', 'Chrome / Windows', 'Chrome', 'Windows', 'Desktop', 'New York', 'United States', 0, None),
        (2, 'sarah_dev', (now - timedelta(hours=12)).strftime('%Y-%m-%d %H:%M:%S'), '192.168.1.100', 'SUCCESS', 'Chrome / Windows', 'Chrome', 'Windows', 'Desktop', 'New York', 'United States', 0, None),

        # Normal Alex Logins (London, UK)
        (3, 'alex_analyst', (now - timedelta(hours=30)).strftime('%Y-%m-%d %H:%M:%S'), '10.0.0.15', 'SUCCESS', 'Firefox / macOS', 'Firefox', 'macOS', 'Laptop', 'London', 'United Kingdom', 0, None),
        (3, 'alex_analyst', (now - timedelta(hours=18)).strftime('%Y-%m-%d %H:%M:%S'), '10.0.0.15', 'SUCCESS', 'Firefox / macOS', 'Firefox', 'macOS', 'Laptop', 'London', 'United Kingdom', 0, None),

        # Normal Admin Logins
        (1, 'admin', (now - timedelta(hours=48)).strftime('%Y-%m-%d %H:%M:%S'), '127.0.0.1', 'SUCCESS', 'Edge / Windows', 'Edge', 'Windows', 'Workstation', 'Local Workstation', 'Internal Network', 0, None),
        (1, 'admin', (now - timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'), '127.0.0.1', 'SUCCESS', 'Edge / Windows', 'Edge', 'Windows', 'Workstation', 'Local Workstation', 'Internal Network', 0, None),

        # Historical Brute Force Incident on john_user (Moscow IP)
        (4, 'john_user', (now - timedelta(hours=6, minutes=15)).strftime('%Y-%m-%d %H:%M:%S'), '198.51.100.22', 'FAILED', 'Python-requests/2.31', 'Bot', 'Linux', 'Server', 'Moscow', 'Russia', 1, 'Invalid password'),
        (4, 'john_user', (now - timedelta(hours=6, minutes=13)).strftime('%Y-%m-%d %H:%M:%S'), '198.51.100.22', 'FAILED', 'Python-requests/2.31', 'Bot', 'Linux', 'Server', 'Moscow', 'Russia', 1, 'Invalid password'),
        (4, 'john_user', (now - timedelta(hours=6, minutes=11)).strftime('%Y-%m-%d %H:%M:%S'), '198.51.100.22', 'FAILED', 'Python-requests/2.31', 'Bot', 'Linux', 'Server', 'Moscow', 'Russia', 1, 'Invalid password'),

        # Historical Off-Hours Login attempt on sarah_dev (3:20 AM)
        (2, 'sarah_dev', (now - timedelta(days=1)).replace(hour=3, minute=20, second=10).strftime('%Y-%m-%d %H:%M:%S'), '192.168.1.100', 'SUCCESS', 'Chrome / Windows', 'Chrome', 'Windows', 'Desktop', 'New York', 'United States', 1, None),
    ]

    for log in sample_logins:
        cursor.execute("""
            INSERT INTO login_activity (user_id, username, timestamp, ip_address, status, user_agent, browser, os, device, city, country, is_suspicious, failure_reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, log)

    # Seed Historical Alerts matching the suspicious logins
    # Alert for John's brute force (Activity ID 10)
    cursor.execute("""
        INSERT INTO security_alerts (activity_id, username, alert_type, severity, reason, status, created_at)
        VALUES (
            10,
            'john_user',
            'BRUTE_FORCE',
            'HIGH',
            'Multiple failed login attempts (3 failed attempts within 10 minutes from Moscow, Russia).',
            'RESOLVED',
            ?
        )
    """, ((now - timedelta(hours=6, minutes=11)).strftime('%Y-%m-%d %H:%M:%S'),))

    # Alert for Sarah's off-hours login (Activity ID 11)
    cursor.execute("""
        INSERT INTO security_alerts (activity_id, username, alert_type, severity, reason, status, created_at)
        VALUES (
            11,
            'sarah_dev',
            'OFF_HOURS',
            'LOW',
            'Login activity detected during off-peak hours (03:20 AM).',
            'PENDING',
            ?
        )
    """, ((now - timedelta(days=1)).replace(hour=3, minute=20, second=10).strftime('%Y-%m-%d %H:%M:%S'),))

    conn.commit()
    conn.close()

def reset_database(db_path=None):
    """Drops existing tables, recreates schema, and seeds clean initial data."""
    conn = get_db(db_path)
    cursor = conn.cursor()
    cursor.execute("DROP TABLE IF EXISTS security_alerts;")
    cursor.execute("DROP TABLE IF EXISTS login_activity;")
    cursor.execute("DROP TABLE IF EXISTS users;")
    conn.commit()
    conn.close()
    init_db(db_path)
    seed_database(db_path)
