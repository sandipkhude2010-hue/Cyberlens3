import sqlite3
from datetime import datetime, timedelta
import pandas as pd
from config import Config
from database import get_db

class AnomalyDetector:
    """
    Rule-based Anomaly Detection Engine powered by Python & Pandas.
    Evaluates authentication events in real-time against threat signatures.
    """

    def __init__(self, db_path=None):
        self.db_path = db_path or Config.DATABASE

    def analyze_login_attempt(self, activity_id, username, ip_address, status, timestamp_str, city=None, country=None):
        """
        Main inspection routine called immediately after a login is recorded.
        Evaluates the 6 anomaly rules and commits alerts to the database.
        """
        conn = get_db(self.db_path)
        triggered_alerts = []

        try:
            current_time = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            current_time = datetime.now()
            timestamp_str = current_time.strftime('%Y-%m-%d %H:%M:%S')

        # Load recent activity window into a Pandas DataFrame for vectorized analysis
        query = """
            SELECT id, user_id, username, timestamp, ip_address, status, city, country, is_suspicious
            FROM login_activity
            WHERE username = ? OR ip_address = ?
            ORDER BY timestamp DESC
            LIMIT 150
        """
        df = pd.read_sql_query(query, conn, params=(username, ip_address))

        if not df.empty:
            df['dt'] = pd.to_datetime(df['timestamp'])
        else:
            df['dt'] = pd.Series(dtype='datetime64[ns]')

        # -------------------------------------------------------------
        # RULE 1: Multiple Failed Login Attempts (Brute Force)
        # -------------------------------------------------------------
        bf_window_start = current_time - timedelta(minutes=Config.BRUTE_FORCE_WINDOW_MINUTES)
        user_failures = df[(df['username'] == username) & 
                           (df['status'] == 'FAILED') & 
                           (df['dt'] >= bf_window_start)]
        
        if len(user_failures) >= Config.BRUTE_FORCE_THRESHOLD:
            count = len(user_failures)
            triggered_alerts.append({
                'alert_type': 'BRUTE_FORCE',
                'severity': 'HIGH',
                'reason': f"Possible Brute-Force attack: {count} failed login attempts detected within {Config.BRUTE_FORCE_WINDOW_MINUTES} minutes for user '{username}'."
            })

        # -------------------------------------------------------------
        # RULE 2: Repeated Attempts from Multiple IP Addresses (Distributed Attack / Credential Stuffing)
        # -------------------------------------------------------------
        dist_window_start = current_time - timedelta(minutes=Config.DISTRIBUTED_IP_WINDOW_MINUTES)
        user_recent_activity = df[(df['username'] == username) & (df['dt'] >= dist_window_start)]
        distinct_ips = user_recent_activity['ip_address'].nunique()

        if distinct_ips >= Config.DISTRIBUTED_IP_THRESHOLD:
            ip_list = ", ".join(user_recent_activity['ip_address'].unique().tolist())
            triggered_alerts.append({
                'alert_type': 'IP_HOPPING',
                'severity': 'HIGH',
                'reason': f"Distributed attack signature: Account '{username}' targeted from {distinct_ips} different IP addresses ({ip_list}) within {Config.DISTRIBUTED_IP_WINDOW_MINUTES} minutes."
            })

        # -------------------------------------------------------------
        # RULE 3: Login from Unusual Location (Impossible Travel / Geolocation Anomaly)
        # -------------------------------------------------------------
        if city and country and city != 'Unknown':
            # Query historical successful logins for this user from SQLite
            history_query = """
                SELECT city, country, timestamp FROM login_activity
                WHERE username = ? AND status = 'SUCCESS' AND id != ?
                ORDER BY timestamp DESC
                LIMIT 50
            """
            hist_df = pd.read_sql_query(history_query, conn, params=(username, activity_id))

            if not hist_df.empty:
                known_locations = set(zip(hist_df['city'].dropna(), hist_df['country'].dropna()))
                current_loc = (city, country)

                if current_loc not in known_locations and len(known_locations) > 0:
                    hist_df['dt'] = pd.to_datetime(hist_df['timestamp'])
                    last_success = hist_df.iloc[0]
                    last_city = last_success['city']
                    last_country = last_success['country']
                    last_time = last_success['dt']
                    time_diff = (current_time - last_time).total_seconds() / 3600.0  # in hours

                    # Check for Impossible Travel (different city/country within less than 3 hours)
                    if time_diff < 3.0 and last_city != city:
                        triggered_alerts.append({
                            'alert_type': 'GEOLOCATION_ANOMALY',
                            'severity': 'HIGH',
                            'reason': f"Impossible Travel anomaly: Login from {city}, {country} just {time_diff:.1f} hours after successful login from {last_city}, {last_country}."
                        })
                    else:
                        known_str = ", ".join([f"{c}, {k}" for c, k in list(known_locations)[:3]])
                        triggered_alerts.append({
                            'alert_type': 'GEOLOCATION_ANOMALY',
                            'severity': 'MEDIUM',
                            'reason': f"Unusual location detected: Login attempt from {city}, {country}. User's established baseline: {known_str}."
                        })

        # -------------------------------------------------------------
        # RULE 4: Login at Unusual Hours (Off-Hours Anomaly)
        # -------------------------------------------------------------
        hour = current_time.hour
        if Config.OFF_HOURS_START <= hour <= Config.OFF_HOURS_END:
            time_formatted = current_time.strftime('%I:%M %p')
            severity = 'MEDIUM' if status == 'FAILED' else 'LOW'
            triggered_alerts.append({
                'alert_type': 'OFF_HOURS',
                'severity': severity,
                'reason': f"Off-hours authentication detected at {time_formatted} (Deep night window {Config.OFF_HOURS_START:02d}:00 - {Config.OFF_HOURS_END:02d}:00)."
            })

        # -------------------------------------------------------------
        # RULE 5: High-Frequency / Rapid Bot Attempts
        # -------------------------------------------------------------
        burst_window_start = current_time - timedelta(seconds=Config.RAPID_BURST_WINDOW_SECONDS)
        burst_df = df[(df['ip_address'] == ip_address) & (df['dt'] >= burst_window_start)]
        
        if len(burst_df) >= Config.RAPID_BURST_THRESHOLD:
            count = len(burst_df)
            triggered_alerts.append({
                'alert_type': 'RAPID_BURST',
                'severity': 'HIGH',
                'reason': f"Automated bot traffic detected: {count} rapid login attempts within {Config.RAPID_BURST_WINDOW_SECONDS} seconds from IP {ip_address}."
            })

        # -------------------------------------------------------------
        # RULE 6: Successful Login Following Repeated Failed Attempts
        # -------------------------------------------------------------
        if status == 'SUCCESS':
            post_fail_window = current_time - timedelta(minutes=Config.FAILED_THEN_SUCCESS_WINDOW_MINUTES)
            recent_fails = df[(df['username'] == username) & 
                              (df['status'] == 'FAILED') & 
                              (df['dt'] >= post_fail_window) &
                              (df['dt'] < current_time)]
            
            if len(recent_fails) >= Config.FAILED_THEN_SUCCESS_PRIOR_FAILURES:
                fail_count = len(recent_fails)
                triggered_alerts.append({
                    'alert_type': 'FAILED_THEN_SUCCESS',
                    'severity': 'HIGH',
                    'reason': f"Account Breach Pattern: Successful login achieved immediately following {fail_count} failed attempts within {Config.FAILED_THEN_SUCCESS_WINDOW_MINUTES} minutes."
                })

        # -------------------------------------------------------------
        # Persist Alerts and Update Activity Status
        # -------------------------------------------------------------
        cursor = conn.cursor()
        if triggered_alerts:
            # Mark activity row as suspicious
            cursor.execute("UPDATE login_activity SET is_suspicious = 1 WHERE id = ?", (activity_id,))

            # Deduplicate alerts for this activity if same alert_type exists
            seen_types = set()
            saved_alerts = []
            for alert in triggered_alerts:
                if alert['alert_type'] not in seen_types:
                    seen_types.add(alert['alert_type'])
                    cursor.execute("""
                        INSERT INTO security_alerts (activity_id, username, alert_type, severity, reason, status, created_at)
                        VALUES (?, ?, ?, ?, ?, 'PENDING', ?)
                    """, (activity_id, username, alert['alert_type'], alert['severity'], alert['reason'], timestamp_str))
                    alert['id'] = cursor.lastrowid
                    alert['timestamp'] = timestamp_str
                    saved_alerts.append(alert)

            conn.commit()
            conn.close()
            return saved_alerts
        else:
            conn.close()
            return []

    def get_security_analytics(self):
        """
        Performs data aggregation and statistical analysis with Pandas
        to supply real-time metrics and Chart.js datasets for the Admin Dashboard.
        """
        conn = get_db(self.db_path)

        # 1. Total Metrics
        logins_df = pd.read_sql_query("SELECT * FROM login_activity", conn)
        alerts_df = pd.read_sql_query("SELECT * FROM security_alerts", conn)
        conn.close()

        total_attempts = len(logins_df)
        success_count = len(logins_df[logins_df['status'] == 'SUCCESS']) if not logins_df.empty else 0
        failed_count = len(logins_df[logins_df['status'] == 'FAILED']) if not logins_df.empty else 0
        total_alerts = len(alerts_df)
        pending_alerts = len(alerts_df[alerts_df['status'] == 'PENDING']) if not alerts_df.empty else 0
        resolved_alerts = len(alerts_df[alerts_df['status'] == 'RESOLVED']) if not alerts_df.empty else 0

        failure_rate = round((failed_count / total_attempts * 100), 1) if total_attempts > 0 else 0.0

        # 2. Activity Trends (Grouped by Date/Hour or Day)
        trends = {'labels': [], 'success': [], 'failed': []}
        if not logins_df.empty:
            logins_df['dt'] = pd.to_datetime(logins_df['timestamp'])
            logins_df['hour_bin'] = logins_df['dt'].dt.strftime('%m-%d %H:00')
            
            # Sort by hour bin and take the most recent 12 active time bins
            grouped = logins_df.groupby(['hour_bin', 'status']).size().unstack(fill_value=0)
            if 'SUCCESS' not in grouped.columns:
                grouped['SUCCESS'] = 0
            if 'FAILED' not in grouped.columns:
                grouped['FAILED'] = 0
            
            grouped = grouped.tail(12)
            trends['labels'] = [str(x) for x in grouped.index.tolist()]
            trends['success'] = [int(x) for x in grouped['SUCCESS'].tolist()]
            trends['failed'] = [int(x) for x in grouped['FAILED'].tolist()]

        # 3. Threat Severity Distribution
        severity_dist = {'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        if not alerts_df.empty:
            sev_counts = alerts_df['severity'].value_counts().to_dict()
            for k in severity_dist:
                severity_dist[k] = int(sev_counts.get(k, 0))

        # 4. Attack Types Breakdown
        attack_types = {}
        if not alerts_df.empty:
            type_counts = alerts_df['alert_type'].value_counts().to_dict()
            type_labels = {
                'BRUTE_FORCE': 'Brute Force',
                'IP_HOPPING': 'Multi-IP / Distributed',
                'GEOLOCATION_ANOMALY': 'Geo Anomaly / Travel',
                'OFF_HOURS': 'Off-Hours Login',
                'RAPID_BURST': 'Rapid Bot Burst',
                'FAILED_THEN_SUCCESS': 'Breach (Failed -> Success)'
            }
            for k, v in type_counts.items():
                attack_types[type_labels.get(k, k)] = int(v)

        # 5. 24-Hour Cycle Activity Distribution (Hour 0 to 23)
        hourly_dist = [0] * 24
        if not logins_df.empty:
            hour_counts = logins_df['dt'].dt.hour.value_counts().to_dict()
            for h in range(24):
                hourly_dist[h] = int(hour_counts.get(h, 0))

        return {
            'metrics': {
                'total_attempts': total_attempts,
                'success_count': success_count,
                'failed_count': failed_count,
                'total_alerts': total_alerts,
                'pending_alerts': pending_alerts,
                'resolved_alerts': resolved_alerts,
                'failure_rate': failure_rate
            },
            'trends': trends,
            'severity_dist': severity_dist,
            'attack_types': attack_types,
            'hourly_dist': hourly_dist
        }
