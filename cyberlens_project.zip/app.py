import os
import io
import csv
import re
import requests
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, Response
from werkzeug.security import generate_password_hash, check_password_hash

from config import Config
from database import init_db, seed_database, get_db, reset_database
from detector import AnomalyDetector
from simulator import AttackSimulator

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database schema and baseline data on startup
init_db()
seed_database()

detector = AnomalyDetector()
simulator = AttackSimulator()

# -------------------------------------------------------------------------
# Helper Functions & Decorators
# -------------------------------------------------------------------------

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Authentication required. Please sign in to access CyberLens.', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def parse_user_agent(ua_string):
    """Extracts Browser, OS, and Device categorization from user agent string."""
    ua = (ua_string or '').lower()
    
    # Browser
    if 'edg' in ua:
        browser = 'Edge'
    elif 'chrome' in ua and 'safari' in ua:
        browser = 'Chrome'
    elif 'firefox' in ua:
        browser = 'Firefox'
    elif 'safari' in ua and 'chrome' not in ua:
        browser = 'Safari'
    elif 'python' in ua or 'hydra' in ua or 'bot' in ua or 'curl' in ua:
        browser = 'Automated Script/Bot'
    else:
        browser = 'Generic Browser'

    # OS
    if 'windows' in ua:
        os_name = 'Windows'
    elif 'macintosh' in ua or 'mac os' in ua:
        os_name = 'macOS'
    elif 'linux' in ua:
        os_name = 'Linux'
    elif 'android' in ua:
        os_name = 'Android'
    elif 'iphone' in ua or 'ipad' in ua:
        os_name = 'iOS'
    else:
        os_name = 'Unknown OS'

    # Device
    if 'mobile' in ua or 'iphone' in ua or 'android' in ua:
        device = 'Mobile'
    elif 'ipad' in ua or 'tablet' in ua:
        device = 'Tablet'
    elif 'bot' in ua or 'crawler' in ua or 'python' in ua:
        device = 'Server/Bot'
    else:
        device = 'Desktop'

    return browser, os_name, device

_GEO_CACHE = {}

def resolve_ip_location(ip):
    """Maps client IP to geographic location using demo mapping or real-time GeoIP API for global visitors."""
    if not ip or ip == '127.0.0.1' or ip.startswith('192.168.') or ip.startswith('10.'):
        return ('Local Network', 'Internal Network')
    if ip in Config.DEMO_GEO_MAP:
        return Config.DEMO_GEO_MAP[ip]
    if ip in _GEO_CACHE:
        return _GEO_CACHE[ip]

    # Query public GeoIP service for real worldwide visitors
    try:
        resp = requests.get(f"http://ip-api.com/json/{ip}?fields=status,country,city", timeout=1.8)
        if resp.status_code == 200:
            data = resp.json()
            if data.get('status') == 'success' and data.get('city') and data.get('country'):
                loc = (data['city'], data['country'])
                _GEO_CACHE[ip] = loc
                return loc
    except Exception:
        pass

    return ('Unknown City', 'External Network')

# -------------------------------------------------------------------------
# Authentication Routes
# -------------------------------------------------------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    # Global Client IP detection (Cloudflare Tunnel header first, then proxies, then remote_addr)
    client_ip = (
        request.headers.get('CF-Connecting-IP') or
        request.headers.get('X-Real-IP') or
        (request.headers.get('X-Forwarded-For', '').split(',')[0].strip() if request.headers.get('X-Forwarded-For') else None) or
        request.remote_addr or
        '127.0.0.1'
    )

    user_agent = request.headers.get('User-Agent', '')
    browser, os_name, device = parse_user_agent(user_agent)
    city, country = resolve_ip_location(client_ip)

    if request.method == 'POST':
        login_input = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not login_input or not password:
            flash('Username/email and password are required.', 'danger')
            return render_template('login.html', client_ip=client_ip, browser=browser, os_name=os_name, city=city, country=country)

        conn = get_db()
        cursor = conn.cursor()
        # Allows logging in with either username OR real email address (case-insensitive)
        cursor.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)", (login_input, login_input))
        user = cursor.fetchone()

        # If user found, use their canonical username; otherwise fallback to the inputted identifier
        username = user['username'] if user else login_input
        now_dt = datetime.now()
        timestamp_str = now_dt.strftime('%Y-%m-%d %H:%M:%S')

        # Authentication Check
        if user and check_password_hash(user['password_hash'], password):
            # SUCCESSFUL LOGIN
            cursor.execute("""
                INSERT INTO login_activity (
                    user_id, username, timestamp, ip_address, status,
                    user_agent, browser, os, device, city, country, is_suspicious, failure_reason
                ) VALUES (?, ?, ?, ?, 'SUCCESS', ?, ?, ?, ?, ?, ?, 0, NULL)
            """, (user['id'], username, timestamp_str, client_ip, user_agent, browser, os_name, device, city, country))
            
            activity_id = cursor.lastrowid
            
            # Update user's last login timestamp
            cursor.execute("UPDATE users SET last_login = ? WHERE id = ?", (timestamp_str, user['id']))
            conn.commit()
            conn.close()

            # Run Real-Time Anomaly Detection
            alerts = detector.analyze_login_attempt(
                activity_id=activity_id,
                username=username,
                ip_address=client_ip,
                status='SUCCESS',
                timestamp_str=timestamp_str,
                city=city,
                country=country
            )

            # Establish Session
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['email'] = user['email']

            if alerts:
                flash(f"Welcome back, {username}! Note: {len(alerts)} suspicious pattern(s) flagged during authentication.", "warning")
            else:
                flash(f"Welcome back, {username}! Authentication successful.", "success")

            return redirect(url_for('dashboard'))
        else:
            # FAILED LOGIN
            failure_reason = 'Invalid credentials' if user else 'Unregistered account'
            user_id = user['id'] if user else None

            cursor.execute("""
                INSERT INTO login_activity (
                    user_id, username, timestamp, ip_address, status,
                    user_agent, browser, os, device, city, country, is_suspicious, failure_reason
                ) VALUES (?, ?, ?, ?, 'FAILED', ?, ?, ?, ?, ?, ?, 0, ?)
            """, (user_id, username, timestamp_str, client_ip, user_agent, browser, os_name, device, city, country, failure_reason))

            activity_id = cursor.lastrowid
            conn.commit()
            conn.close()

            # Run Real-Time Anomaly Detection on Failure
            alerts = detector.analyze_login_attempt(
                activity_id=activity_id,
                username=username,
                ip_address=client_ip,
                status='FAILED',
                timestamp_str=timestamp_str,
                city=city,
                country=country
            )

            if alerts:
                flash('Login failed. Security Warning: Suspicious activity signature detected on this account.', 'danger')
            else:
                flash('Invalid username/email or password. Please try again.', 'danger')

            return render_template('login.html', client_ip=client_ip, browser=browser, os_name=os_name, city=city, country=country)

    return render_template('login.html', client_ip=client_ip, browser=browser, os_name=os_name, city=city, country=country)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Validations for real worldwide users
        if not username or len(username) < 3:
            flash('Username must be at least 3 characters long.', 'danger')
            return render_template('register.html')
        
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        if not email or not re.match(email_regex, email):
            flash('Please enter a valid email address (e.g. yourname@gmail.com).', 'danger')
            return render_template('register.html')

        if not password or len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return render_template('register.html')
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)", (username, email))
        if cursor.fetchone():
            conn.close()
            flash('An account with this username or email already exists. Please choose another or sign in.', 'warning')
            return render_template('register.html')

        pwd_hash = generate_password_hash(password)
        now_str = datetime.now().isoformat()
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, role, created_at)
            VALUES (?, ?, ?, 'user', ?)
        """, (username, email, pwd_hash, now_str))
        conn.commit()
        conn.close()

        flash('Registration successful! You can now log in using your username or real email address.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been signed out successfully.', 'info')
    return redirect(url_for('login'))

# -------------------------------------------------------------------------
# SOC Admin Dashboard
# -------------------------------------------------------------------------

@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db()
    cursor = conn.cursor()

    # Fetch recent login events (latest 10)
    cursor.execute("""
        SELECT * FROM login_activity
        ORDER BY timestamp DESC
        LIMIT 10
    """)
    recent_logins = cursor.fetchall()

    # Fetch recent pending security alerts (latest 6)
    cursor.execute("""
        SELECT * FROM security_alerts
        WHERE status = 'PENDING'
        ORDER BY created_at DESC
        LIMIT 6
    """)
    recent_alerts = cursor.fetchall()

    conn.close()

    # Compute live analytics via Pandas
    analytics = detector.get_security_analytics()

    return render_template(
        'dashboard.html',
        metrics=analytics['metrics'],
        recent_logins=recent_logins,
        recent_alerts=recent_alerts
    )

# -------------------------------------------------------------------------
# Security Alerts Management
# -------------------------------------------------------------------------

@app.route('/alerts')
@login_required
def alerts():
    severity_filter = request.args.get('severity', 'ALL').upper()
    status_filter = request.args.get('status', 'ALL').upper()
    search = request.args.get('search', '').strip()

    conn = get_db()
    cursor = conn.cursor()

    query = """
        SELECT a.*, l.ip_address, l.city, l.country, l.browser, l.os, l.device
        FROM security_alerts a
        LEFT JOIN login_activity l ON a.activity_id = l.id
        WHERE 1=1
    """
    params = []

    if severity_filter in ['HIGH', 'MEDIUM', 'LOW']:
        query += " AND a.severity = ?"
        params.append(severity_filter)

    if status_filter in ['PENDING', 'RESOLVED']:
        query += " AND a.status = ?"
        params.append(status_filter)

    if search:
        query += " AND (a.username LIKE ? OR a.reason LIKE ? OR a.alert_type LIKE ? OR l.ip_address LIKE ?)"
        term = f"%{search}%"
        params.extend([term, term, term, term])

    query += " ORDER BY a.created_at DESC"
    cursor.execute(query, params)
    alerts_list = cursor.fetchall()

    # Count breakdown
    cursor.execute("SELECT COUNT(*) FROM security_alerts WHERE status = 'PENDING'")
    pending_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM security_alerts WHERE severity = 'HIGH' AND status = 'PENDING'")
    high_pending_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM security_alerts WHERE status = 'RESOLVED'")
    resolved_count = cursor.fetchone()[0]

    conn.close()

    return render_template(
        'alerts.html',
        alerts=alerts_list,
        severity_filter=severity_filter,
        status_filter=status_filter,
        search=search,
        pending_count=pending_count,
        high_pending_count=high_pending_count,
        resolved_count=resolved_count
    )

@app.route('/api/alerts/<int:alert_id>/resolve', methods=['POST'])
@login_required
def resolve_alert(alert_id):
    conn = get_db()
    cursor = conn.cursor()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    resolved_by = session.get('username', 'admin')

    cursor.execute("""
        UPDATE security_alerts
        SET status = 'RESOLVED', resolved_at = ?, resolved_by = ?
        WHERE id = ?
    """, (now_str, resolved_by, alert_id))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': f'Alert #{alert_id} marked as resolved by {resolved_by}.', 'resolved_at': now_str})

@app.route('/api/alerts/<int:alert_id>/dismiss', methods=['POST'])
@login_required
def dismiss_alert(alert_id):
    conn = get_db()
    cursor = conn.cursor()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    resolved_by = session.get('username', 'admin')

    cursor.execute("""
        UPDATE security_alerts
        SET status = 'RESOLVED', resolved_at = ?, resolved_by = ?
        WHERE id = ?
    """, (now_str, f"{resolved_by} (Dismissed)", alert_id))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': f'Alert #{alert_id} dismissed.', 'resolved_at': now_str})

# -------------------------------------------------------------------------
# Login History Explorer & Audit Trail
# -------------------------------------------------------------------------

@app.route('/logs')
@login_required
def logs():
    username_filter = request.args.get('username', '').strip()
    status_filter = request.args.get('status', 'ALL').upper()
    ip_filter = request.args.get('ip', '').strip()
    suspicious_only = request.args.get('suspicious') == '1'

    conn = get_db()
    cursor = conn.cursor()

    query = "SELECT * FROM login_activity WHERE 1=1"
    params = []

    if username_filter:
        query += " AND username LIKE ?"
        params.append(f"%{username_filter}%")

    if status_filter in ['SUCCESS', 'FAILED']:
        query += " AND status = ?"
        params.append(status_filter)

    if ip_filter:
        query += " AND ip_address LIKE ?"
        params.append(f"%{ip_filter}%")

    if suspicious_only:
        query += " AND is_suspicious = 1"

    query += " ORDER BY timestamp DESC LIMIT 300"
    cursor.execute(query, params)
    log_records = cursor.fetchall()

    conn.close()

    return render_template(
        'logs.html',
        logs=log_records,
        username_filter=username_filter,
        status_filter=status_filter,
        ip_filter=ip_filter,
        suspicious_only=suspicious_only
    )

@app.route('/api/logs/export')
@login_required
def export_logs():
    """Generates and downloads a clean CSV audit report using Pandas."""
    import pandas as pd
    conn = get_db()
    df = pd.read_sql_query("SELECT * FROM login_activity ORDER BY timestamp DESC", conn)
    conn.close()

    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)

    filename = f"cyberlens_audit_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

# -------------------------------------------------------------------------
# Attack Simulation & Testing Lab
# -------------------------------------------------------------------------

@app.route('/simulator')
@login_required
def simulator_view():
    return render_template('simulator.html')

@app.route('/api/simulator/run', methods=['POST'])
@login_required
def run_simulation():
    data = request.get_json() or {}
    scenario = data.get('scenario', 'normal')
    target_user = data.get('target_user', 'sarah_dev')

    result = simulator.run_scenario(scenario_type=scenario, target_user=target_user)
    return jsonify({'success': True, 'data': result})

@app.route('/api/simulator/reset', methods=['POST'])
@login_required
def reset_demo_data():
    reset_database()
    return jsonify({'success': True, 'message': 'Database reinitialized to baseline demonstration state.'})

# -------------------------------------------------------------------------
# Chart & Real-Time Stats API
# -------------------------------------------------------------------------

@app.route('/api/dashboard/stats')
@login_required
def dashboard_stats_api():
    """Supplies live Chart.js datasets and KPI values."""
    analytics = detector.get_security_analytics()
    return jsonify(analytics)

@app.route('/robots.txt')
def robots():
    return app.send_static_file('robots.txt')

@app.route('/sitemap.xml')
def sitemap():
    return app.send_static_file('sitemap.xml')

if __name__ == '__main__':
    try:
        from waitress import serve
        print("Serving CyberLens with Waitress multi-threaded WSGI on http://0.0.0.0:5000 ...")
        serve(app, host='0.0.0.0', port=5000, threads=10)
    except ImportError:
        app.run(host='0.0.0.0', port=5000, debug=False)
