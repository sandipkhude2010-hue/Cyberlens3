import socket
import threading
import time
import sys
import requests

LOCAL_PORT = 5000
SUBDOMAIN = "cyberlens-detector"
SERVER_URL = f"https://loca.lt/{SUBDOMAIN}"

def bridge(src, dst):
    """Pipes all bytes between two TCP sockets bidirectionally."""
    try:
        while True:
            data = src.recv(8192)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        try:
            src.close()
        except Exception:
            pass
        try:
            dst.close()
        except Exception:
            pass

def handle_connection(remote_host, remote_port, pool_manager):
    """Bridges one connection between loca.lt and local Waitress server."""
    try:
        remote_sock = socket.create_connection((remote_host, remote_port), timeout=30)
        local_sock = socket.create_connection(('127.0.0.1', LOCAL_PORT), timeout=10)

        pool_manager['active'] += 1

        t1 = threading.Thread(target=bridge, args=(remote_sock, local_sock), daemon=True)
        t2 = threading.Thread(target=bridge, args=(local_sock, remote_sock), daemon=True)
        t1.start()
        t2.start()
        t1.join()
        t2.join()

    except Exception as e:
        pass
    finally:
        pool_manager['active'] = max(0, pool_manager['active'] - 1)

def run_tunnel():
    print(f"[*] Requesting custom subdomain '{SUBDOMAIN}' from loca.lt...", flush=True)
    while True:
        try:
            resp = requests.get(SERVER_URL, timeout=10)
            if resp.status_code != 200:
                print(f"[!] Server returned {resp.status_code}, retrying...", flush=True)
                time.sleep(3)
                continue

            info = resp.json()
            remote_host = "loca.lt"
            remote_port = info["port"]
            max_conn = max(info.get("max_conn_count", 4), 4)
            public_url = info.get("url", f"https://{SUBDOMAIN}.loca.lt")

            print(f"[+] CyberLens branded tunnel live at: {public_url}", flush=True)
            print(f"[*] Endpoint: {remote_host}:{remote_port} (Pool size: {max_conn})", flush=True)

            pool_manager = {'active': 0}

            while True:
                while pool_manager['active'] < max_conn:
                    t = threading.Thread(
                        target=handle_connection,
                        args=(remote_host, remote_port, pool_manager),
                        daemon=True
                    )
                    t.start()
                    time.sleep(0.05)
                time.sleep(0.5)

        except Exception as e:
            print(f"[!] Error: {e}. Reconnecting...", flush=True)
            time.sleep(3)

if __name__ == '__main__':
    run_tunnel()
