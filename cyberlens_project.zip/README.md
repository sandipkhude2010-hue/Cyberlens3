# CyberLens — Suspicious Login Activity Detector

CyberLens is a comprehensive, production-grade cybersecurity web application that monitors authentication attempts, analyzes access patterns in real-time using **Python & Pandas**, and detects unauthorized or anomalous activities through a **rule-based anomaly detection engine**.

Designed specifically for academic evaluation, mini-project viva demonstrations, and enterprise security monitoring prototypes.

---

## 1. System Architecture & Workflow

```
[User / Attacker Authentication]
            │
            ▼
[Flask Request Capture] ──> (Extracts IP, User-Agent, Browser, OS, Device, Timestamp)
            │
            ▼
[SQLite Activity Persistence] ──> (`login_activity` table)
            │
            ▼
[Pandas Real-Time Anomaly Engine] ──> Evaluates 6 Detection Rules via Time-Windows & Vectors
            │
            ├──> If Anomalous ──> Generates Alert (`security_alerts` table) with Severity & Reason
            └──> If Normal    ──> Verified & Permitted
            │
            ▼
[CyberLens SOC Dashboard] ──> Real-Time KPIs, 4 Chart.js Visualizations, Alerts Triage & Audit Trail
```

---

## 2. Technology Stack

- **Frontend**: HTML5, CSS3 (Modern Cyber Navy theme with teal & emerald glow), Vanilla JavaScript
- **Backend & WSGI**: Python Flask 3.x with **Waitress** Multi-Threaded Production WSGI Server
- **Data Analysis**: Python 3 & **Pandas** (Vectorized time-window aggregations and statistical calculations)
- **Database**: SQLite 3 (Normalized tables with foreign key constraints and indices)
- **Data Visualization**: Chart.js 4.x
- **GeoIP & Telemetry**: Cloudflare CF-Connecting-IP & Real-Time Global Geolocation Resolution
- **Security**: PBKDF2 Password Hashing (Werkzeug Security), Email & Username Flexible Sign-In, Session Security, SQL Parameterization

---

## 3. Detection Engine & Rule Specification

The system continuously evaluates every authentication attempt against six deterministic security rules:

| Rule | Attack Signature | Trigger Condition | Severity |
| :--- | :--- | :--- | :--- |
| **Rule 1** | **Brute-Force Password Spray** | $\ge 3$ consecutive failed attempts for a user within $10\text{ minutes}$ | `HIGH` |
| **Rule 2** | **Distributed IP Hopping** | Same user targeted from $\ge 2$ distinct IP addresses within $15\text{ minutes}$ | `HIGH` |
| **Rule 3** | **Geolocation Anomaly / Impossible Travel** | Login location deviates from user baseline or unrealistic geographic speed ($< 3\text{ hours}$ across continents) | `MEDIUM` / `HIGH` |
| **Rule 4** | **Off-Hours Infiltration** | Login attempted between 01:00 AM and 05:00 AM local time | `LOW` / `MEDIUM` |
| **Rule 5** | **Automated Bot Burst** | $\ge 3$ attempts within $\le 8\text{ seconds}$ from the same IP or targeting the same account | `HIGH` |
| **Rule 6** | **Compromised Account (Fail $\to$ Success)** | Successful login immediately preceded by $\ge 2$ failures within $15\text{ minutes}$ | `HIGH` |

---

## 4. Database Schema

### Table: `users`
- `id` (INTEGER PRIMARY KEY)
- `username` (TEXT UNIQUE NOT NULL)
- `email` (TEXT UNIQUE NOT NULL)
- `password_hash` (TEXT NOT NULL)
- `role` (TEXT NOT NULL DEFAULT 'user')
- `created_at` (TEXT NOT NULL)
- `last_login` (TEXT)

### Table: `login_activity`
- `id` (INTEGER PRIMARY KEY)
- `user_id` (INTEGER FK $\to$ `users.id`)
- `username` (TEXT NOT NULL)
- `timestamp` (TEXT NOT NULL)
- `ip_address` (TEXT NOT NULL)
- `status` (TEXT NOT NULL: `'SUCCESS'` or `'FAILED'`)
- `user_agent` (TEXT)
- `browser` (TEXT)
- `os` (TEXT)
- `device` (TEXT)
- `city` (TEXT)
- `country` (TEXT)
- `is_suspicious` (INTEGER DEFAULT 0)
- `failure_reason` (TEXT)

### Table: `security_alerts`
- `id` (INTEGER PRIMARY KEY)
- `activity_id` (INTEGER FK $\to$ `login_activity.id`)
- `username` (TEXT NOT NULL)
- `alert_type` (TEXT NOT NULL)
- `severity` (TEXT NOT NULL: `'LOW'`, `'MEDIUM'`, `'HIGH'`)
- `reason` (TEXT NOT NULL)
- `status` (TEXT DEFAULT `'PENDING'`: `'PENDING'` or `'RESOLVED'`)
- `created_at` (TEXT NOT NULL)
- `resolved_at` (TEXT)
- `resolved_by` (TEXT)

---

## 5. Quick Start & Execution Guide

### Prerequisites
- Python 3.8 or higher installed on your computer.

### Step 1: Install Dependencies
Open your command prompt or terminal in this project directory:
```bash
pip install -r requirements.txt
```

### Step 2: Run Automated Test Suite
Verify that all 6 anomaly detection rules and database flows pass:
```bash
python test_detector.py
```
*Expected output: `Ran 10 tests in ... OK`*

### Step 3: Start CyberLens Server
```bash
python app.py
```
The server will bind to:
**`http://127.0.0.1:5000`**

Open this URL in your web browser.

---

## 6. Pre-Seeded Demonstration Accounts

| Role | Username | Password | Purpose |
| :--- | :--- | :--- | :--- |
| **Security Admin** | `admin` | `Admin@123` | Full SOC privileges, review alerts, mark resolved |
| **Developer** | `sarah_dev` | `Sarah@2026` | Normal baseline user in New York, USA |
| **SOC Analyst** | `alex_analyst` | `Alex@2026` | Normal baseline user in London, UK |
| **Standard User** | `john_user` | `John@2026` | User with historical brute-force incidents |

*(You can also register any new account using the built-in Registration portal).*

---

## 7. Attack Simulation & Demonstration Lab

CyberLens includes an integrated **Attack Simulation Lab** (`/simulator`) specifically built for viva presentations and evaluator demonstrations:

1. Navigate to **Attack Simulator** in the sidebar.
2. Select any target user (e.g., `sarah_dev`).
3. Click any attack preset:
   - **Normal Authorized Login**: Demonstrates baseline behavior (0 alerts).
   - **Brute-Force Attack**: Spawns 4 rapid failures from Moscow, Russia (Triggers Rule 1 `HIGH` alert).
   - **Distributed IP Hopping**: Simulates credential stuffing across London, Tokyo, and Berlin (Triggers Rule 2 `HIGH` alert).
   - **Off-Hours Authentication**: Simulates login at 03:30 AM (Triggers Rule 4 `LOW`/`MEDIUM` alert).
   - **Account Breach (Fail $\to$ Success)**: Simulates 3 failures followed immediately by a successful login (Triggers Rule 6 `HIGH` alert).
   - **Automated Bot Burst**: Simulates 4 requests within 2 seconds (Triggers Rule 5 `HIGH` alert).
4. Watch the **Interactive Live Terminal** display real-time forensic detection logs!
5. Navigate to **SOC Dashboard** or **Security Alerts** to triage the newly generated incidents in real time.
6. Click **Reset Baseline Data** at any time to return the database to a pristine initial state.

---

## 8. Viva & Examination Questions & Answers

**Q1: Why is Pandas used in a cybersecurity login detector?**  
*A: Pandas allows vectorized time-window filtering (e.g., rolling time windows with `pd.to_datetime`), fast multi-attribute aggregations (`groupby(['hour_bin', 'status'])`), and instant calculation of distinct IPs (`nunique()`) on tabular authentication streams without complex nested SQL queries.*

**Q2: How does CyberLens prevent SQL Injection?**  
*A: CyberLens strictly uses parameterized queries (`cursor.execute(..., (?, ?))`) across all database operations, ensuring user input is never concatenated into raw SQL statements.*

**Q3: How are passwords secured in the database?**  
*A: Passwords are never stored in plaintext. CyberLens uses Werkzeug's PBKDF2 with SHA-256 password hashing with automatic cryptographic salting.*

**Q4: What is the difference between Rule 1 (Brute-Force) and Rule 2 (Distributed IP)?**  
*A: Rule 1 tracks multiple failed attempts against a single account regardless of origin to identify automated dictionary attacks. Rule 2 tracks multiple distinct IP addresses targeting the same account to identify distributed botnets or credential stuffing attacks attempting to evade single-IP rate limits.*

**Q5: What is Impossible Travel (Rule 3)?**  
*A: Impossible Travel occurs when consecutive logins for the same account occur in two geographically distant locations within a time frame that is physically impossible to traverse via commercial aviation (e.g., New York to Tokyo in 45 minutes).*
