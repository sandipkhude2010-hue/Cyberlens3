import unittest
import json
from app import app
from database import get_db, reset_database

class TestCyberLensIntegration(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        # Reset database before running integration tests
        reset_database()

    def test_01_login_page_renders(self):
        response = self.client.get('/login')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'CyberLens', response.data)
        self.assertIn(b'Active Connection Telemetry', response.data)

    def test_02_login_failure(self):
        response = self.client.post('/login', data={
            'username': 'admin',
            'password': 'WrongPassword123'
        }, follow_redirects=True)
        self.assertTrue(b'Login failed' in response.data or b'Invalid' in response.data)

        # Verify failed attempt was logged
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM login_activity WHERE username = 'admin' AND status = 'FAILED' ORDER BY id DESC LIMIT 1")
        log = cursor.fetchone()
        self.assertIsNotNone(log)
        self.assertEqual(log['status'], 'FAILED')
        conn.close()

    def test_03_login_success_and_session(self):
        response = self.client.post('/login', data={
            'username': 'admin',
            'password': 'Admin@123'
        }, follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn('/dashboard', response.headers['Location'])

        # With session, dashboard should render
        with self.client:
            dash_res = self.client.get('/dashboard')
            self.assertEqual(dash_res.status_code, 200)
            self.assertIn(b'Security Operations Center (SOC) Overview', dash_res.data)
            self.assertIn(b'loginTrendsChart', dash_res.data)
            self.assertIn(b'threatSeverityChart', dash_res.data)

    def test_04_dashboard_stats_api(self):
        # Authenticate first
        self.client.post('/login', data={'username': 'admin', 'password': 'Admin@123'})
        res = self.client.get('/api/dashboard/stats')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertIn('metrics', data)
        self.assertIn('trends', data)
        self.assertIn('severity_dist', data)
        self.assertIn('attack_types', data)
        self.assertIn('hourly_dist', data)
        self.assertGreater(data['metrics']['total_attempts'], 0)

    def test_05_alerts_management_and_resolve_api(self):
        self.client.post('/login', data={'username': 'admin', 'password': 'Admin@123'})
        res = self.client.get('/alerts')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Alerts Triage Queue', res.data)

        # Fetch a pending alert
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM security_alerts WHERE status = 'PENDING' LIMIT 1")
        alert_row = cursor.fetchone()
        self.assertIsNotNone(alert_row)
        alert_id = alert_row[0]
        conn.close()

        # Resolve alert via API
        resolve_res = self.client.post(f'/api/alerts/{alert_id}/resolve')
        self.assertEqual(resolve_res.status_code, 200)
        json_data = json.loads(resolve_res.data)
        self.assertTrue(json_data['success'])

        # Verify status in database
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT status, resolved_by FROM security_alerts WHERE id = ?", (alert_id,))
        updated = cursor.fetchone()
        self.assertEqual(updated['status'], 'RESOLVED')
        self.assertEqual(updated['resolved_by'], 'admin')
        conn.close()

    def test_06_logs_view_and_csv_export(self):
        self.client.post('/login', data={'username': 'admin', 'password': 'Admin@123'})
        logs_res = self.client.get('/logs')
        self.assertEqual(logs_res.status_code, 200)
        self.assertIn(b'Authentication Audit Records', logs_res.data)

        # CSV Export test
        csv_res = self.client.get('/api/logs/export')
        self.assertEqual(csv_res.status_code, 200)
        self.assertEqual(csv_res.mimetype, 'text/csv')
        self.assertIn(b'username,timestamp,ip_address,status', csv_res.data)

    def test_07_simulator_scenarios(self):
        self.client.post('/login', data={'username': 'admin', 'password': 'Admin@123'})
        sim_page = self.client.get('/simulator')
        self.assertEqual(sim_page.status_code, 200)
        self.assertIn(b'Attack Simulation & Rule Demonstration Lab', sim_page.data)

        # Test Brute Force Simulation
        bf_res = self.client.post('/api/simulator/run', 
                                  data=json.dumps({'scenario': 'brute_force', 'target_user': 'sarah_dev'}),
                                  content_type='application/json')
        self.assertEqual(bf_res.status_code, 200)
        bf_data = json.loads(bf_res.data)
        self.assertTrue(bf_data['success'])
        self.assertEqual(bf_data['data']['logs_generated'], 4)

        # Test Breach Simulation (Failed then Success)
        breach_res = self.client.post('/api/simulator/run',
                                      data=json.dumps({'scenario': 'failed_then_success', 'target_user': 'john_user'}),
                                      content_type='application/json')
        self.assertEqual(breach_res.status_code, 200)
        breach_data = json.loads(breach_res.data)
        self.assertTrue(breach_data['success'])

    def test_08_user_registration(self):
        reg_res = self.client.post('/register', data={
            'username': 'new_security_officer',
            'email': 'officer@cyberlens.local',
            'password': 'SecureOfficer@2026',
            'confirm_password': 'SecureOfficer@2026'
        }, follow_redirects=True)
        self.assertEqual(reg_res.status_code, 200)
        self.assertIn(b'Registration successful', reg_res.data)

        # Verify newly registered user can login
        login_res = self.client.post('/login', data={
            'username': 'new_security_officer',
            'password': 'SecureOfficer@2026'
        }, follow_redirects=False)
        self.assertEqual(login_res.status_code, 302)

    def test_09_logout(self):
        self.client.post('/login', data={'username': 'admin', 'password': 'Admin@123'})
        logout_res = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(logout_res.status_code, 200)
        self.assertIn(b'signed out successfully', logout_res.data)

if __name__ == '__main__':
    unittest.main()
